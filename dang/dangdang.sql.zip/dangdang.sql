-- phpMyAdmin SQL Dump
-- version 3.2.0.1
-- http://www.phpmyadmin.net
--
-- 主机: localhost
-- 生成日期: 2018 年 04 月 01 日 11:20
-- 服务器版本: 5.5.8
-- PHP 版本: 5.3.3

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- 数据库: `dangdang`
--

-- --------------------------------------------------------

--
-- 表的结构 `cart`
--

CREATE TABLE IF NOT EXISTS `cart` (
  `sid` tinyint(10) NOT NULL AUTO_INCREMENT,
  `url` varchar(100) NOT NULL,
  `title` varchar(200) CHARACTER SET utf8 NOT NULL,
  `price` varchar(100) NOT NULL,
  `rowprice` varchar(100) NOT NULL,
  `bigurl` varchar(100) NOT NULL,
  PRIMARY KEY (`sid`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=3 ;

--
-- 转存表中的数据 `cart`
--

INSERT INTO `cart` (`sid`, `url`, `title`, `price`, `rowprice`, `bigurl`) VALUES
(1, 'http://img3m9.ddimg.cn/10/18/1062532459-1_k_1.jpg', '湔韩都衣舍2017韩版女秋装新款打底宽松圆领刺绣长袖T恤婋', '96.00', '198.00', 'http://img3m9.ddimg.cn/10/18/1062532459-1_u_1.jpg'),
(2, 'http://img3m8.ddimg.cn/29/20/1366494158-1_k_1.jpg', '韩都衣舍2017韩版女装夏装新款宽松牛仔显瘦背带连衣裙', '98.00', '298.00', 'http://img3m8.ddimg.cn/28/31/1366494058-1_u_1.jpg');

-- --------------------------------------------------------

--
-- 表的结构 `goodslist`
--

CREATE TABLE IF NOT EXISTS `goodslist` (
  `id` tinyint(100) NOT NULL AUTO_INCREMENT,
  `username` varchar(400) CHARACTER SET utf8 NOT NULL,
  `password` varchar(100) NOT NULL,
  `tel` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=9 ;

--
-- 转存表中的数据 `goodslist`
--

INSERT INTO `goodslist` (`id`, `username`, `password`, `tel`, `email`) VALUES
(1, 'liudehua', '123456', '18307062442', '123456@qq.com'),
(2, '习大大', '1234567', '18307062443', '123457@qq.com'),
(3, '123456', '', '13345678911', '123456789@qq.com'),
(4, '1234567', '', '13345678911', '1234567891@qq.com'),
(5, 'zhangsan', '', '13345678910', '1234561789@qq.com'),
(6, '12345678', '123456', '13345678912', '1234567890@qq.com'),
(7, '123456789', 'e10adc3949ba59abbe56e057f20f883e', '13345678900', '123456790@qq.com'),
(8, '654321', '1234567', '13345678999', '654321@qq.com');

-- --------------------------------------------------------

--
-- 表的结构 `maxlunbo`
--

CREATE TABLE IF NOT EXISTS `maxlunbo` (
  `id` tinyint(100) NOT NULL AUTO_INCREMENT,
  `img` varchar(400) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=9 ;

--
-- 转存表中的数据 `maxlunbo`
--

INSERT INTO `maxlunbo` (`id`, `img`) VALUES
(1, 'http://img61.ddimg.cn/2018/3/23/2018032316045654567.jpg'),
(2, 'http://img63.ddimg.cn/2018/3/26/2018032609432070552.jpg'),
(3, 'http://img60.ddimg.cn/2018/3/23/2018032316385010668.jpg'),
(4, 'http://img63.ddimg.cn/2018/3/23/20180323163819589.jpg'),
(5, 'http://img62.ddimg.cn/2018/3/23/201803231707502423.jpg'),
(6, 'http://img60.ddimg.cn/2018/3/23/201803231647031840.jpg'),
(7, 'http://img61.ddimg.cn/2018/3/23/2018032317100072841.jpg'),
(8, 'http://img63.ddimg.cn/2018/3/23/2018032311474195.jpg');

-- --------------------------------------------------------

--
-- 表的结构 `miaosha`
--

CREATE TABLE IF NOT EXISTS `miaosha` (
  `id` tinyint(100) NOT NULL AUTO_INCREMENT,
  `url` varchar(400) NOT NULL,
  `title` varchar(400) CHARACTER SET utf8 NOT NULL,
  `price` varchar(400) NOT NULL,
  `zhekou` varchar(400) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=11 ;

--
-- 转存表中的数据 `miaosha`
--

INSERT INTO `miaosha` (`id`, `url`, `title`, `price`, `zhekou`) VALUES
(1, 'http://img3m7.ddimg.cn/10/10/1322962057-1_l_5.jpg', '【到手价9.9】同时购买其他商品免运费 达芙妮 福袋快来约吧！', '999.9', '999.9'),
(2, 'http://img3m7.ddimg.cn/97/22/24025417-1_l_12.jpg', '摆渡人 （精装）（当当签章版，独家赠送灵魂摆渡路线图）', '999.9', '999.9'),
(3, 'http://img3m9.ddimg.cn/94/12/1316249149-1_l_9.jpg', '正版 说话心理学+人际交往心理学：跟任何人都能交朋友+卡耐基魅力口才与说话技巧+别输在不会表达上说话技巧的书 非暴力幽默沟通学人性的弱点 人际交往演讲与口才社会心理学与生活畅销书籍非暴力沟通', '999.9', '999.9'),
(4, 'http://img3m7.ddimg.cn/97/22/24025417-1_l_12.jpg', '摆渡人 （精装）（当当签章版，独家赠送灵魂摆渡路线图）', '999.9', '999.9'),
(5, 'http://img3m7.ddimg.cn/10/10/1322962057-1_l_5.jpg', '【到手价9.9】同时购买其他商品免运费 达芙妮 福袋快来约吧！', '999.9', '999.9'),
(6, 'http://img3m7.ddimg.cn/48/16/1490285757-1_l_2.jpg', '【品牌抢购 仅此一天】达芙妮休闲圆头平底女单鞋懒人鞋', '999.9', '999.9'),
(7, 'http://img3m7.ddimg.cn/87/15/1053816477-1_l_2.jpg', '【超值秒杀 限量抢购】小清新刺绣学生打底衫2018春装新款韩版白色长袖衬衫女上衣', '999.9', '999.9'),
(8, 'http://img3m7.ddimg.cn/43/9/410260597-1_l_1.jpg', '碟形世界系列套装（共4册）（比《哈利波特》和《魔戒》加起来还好看的，可能只有《碟形世界》！）', '999.9', '999.9'),
(9, 'http://img3m7.ddimg.cn/87/15/1053816477-1_l_2.jpg', '【超值秒杀 限量抢购】小清新刺绣学生打底衫2018春装新款韩版白色长袖衬衫女上衣', '999.9', '999.9'),
(10, 'http://img3m7.ddimg.cn/87/15/1053816477-1_l_2.jpg', '【超值秒杀 限量抢购】小清新刺绣学生打底衫2018春装新款韩版白色长袖衬衫女上衣', '999.9', '999.9');
